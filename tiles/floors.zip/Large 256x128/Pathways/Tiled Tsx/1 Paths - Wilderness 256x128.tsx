<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="Large Tiles" tilewidth="256" tileheight="128" tilecount="12" columns="4">
 <image source="D:/John's Graphic Packs/John's Isometric Tiles/Pathways/1 Wilderness - 256x144.png" trans="000000" width="1024" height="432"/>
</tileset>
