<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="1 Basic Ground - 256x144" tilewidth="256" tileheight="144" tilecount="4" columns="4">
 <image source="D:/John's Graphic Packs/John's Isometric Tiles/Pathways/1 Basic Ground - 256x144.png" trans="000000" width="1024" height="144"/>
</tileset>
