<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="2 Ground - Rocky 256x128" tilewidth="256" tileheight="128" tilecount="15" columns="3">
 <image source="D:/John's Graphic Packs/John's Isometric Tiles/Worldmap/2 Ground - Rocky 256x128.png" trans="000000" width="768" height="640"/>
</tileset>
