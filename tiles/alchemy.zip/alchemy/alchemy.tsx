<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.1" name="alchemy" tilewidth="16" tileheight="16" tilecount="4096" columns="32">
 <image source="alchemy.png" trans="ff00ff" width="512" height="2048"/>
 <tile id="1947">
  <animation>
   <frame tileid="1947" duration="150"/>
   <frame tileid="1948" duration="150"/>
   <frame tileid="1949" duration="150"/>
   <frame tileid="1948" duration="150"/>
  </animation>
 </tile>
 <tile id="2138">
  <animation>
   <frame tileid="2138" duration="100"/>
   <frame tileid="2139" duration="100"/>
   <frame tileid="2140" duration="100"/>
   <frame tileid="2141" duration="100"/>
   <frame tileid="2142" duration="100"/>
   <frame tileid="2143" duration="100"/>
  </animation>
 </tile>
 <tile id="2170">
  <animation>
   <frame tileid="2170" duration="100"/>
   <frame tileid="2171" duration="100"/>
   <frame tileid="2172" duration="100"/>
   <frame tileid="2173" duration="100"/>
   <frame tileid="2174" duration="100"/>
   <frame tileid="2175" duration="100"/>
  </animation>
 </tile>
</tileset>
